import fs from 'fs';
import path from 'path';
import pdfParse from 'pdf-parse';
import mammoth from 'mammoth';
import { ParsedResume, ResumeSection, BulletPoint, Achievement, DocumentMetadata, SectionType, ValidationResult } from '../types';
import { logger } from '../utils/logger';
import { createError } from '../middleware/errorHandler';

export class ResumeParser {
  private static readonly SECTION_PATTERNS = {
    [SectionType.CONTACT]: /^(contact|personal|info|details)/i,
    [SectionType.SUMMARY]: /^(summary|profile|objective|about)/i,
    [SectionType.EXPERIENCE]: /^(experience|work|employment|career|professional)/i,
    [SectionType.EDUCATION]: /^(education|academic|school|university|degree)/i,
    [SectionType.SKILLS]: /^(skills|technical|competencies|expertise|technologies)/i,
    [SectionType.PROJECTS]: /^(projects|portfolio|work samples)/i,
    [SectionType.CERTIFICATIONS]: /^(certifications?|certificates?|licenses?)/i
  };

  private static readonly BULLET_PATTERNS = [
    /^[\s]*[•·▪▫‣⁃]\s*/,  // Unicode bullets
    /^[\s]*[-*+]\s*/,      // ASCII bullets
    /^[\s]*\d+\.\s*/,      // Numbered lists
    /^[\s]*[a-zA-Z]\.\s*/, // Lettered lists
    /^[\s]*\([a-zA-Z0-9]+\)\s*/ // Parenthetical lists
  ];

  private static readonly ACHIEVEMENT_INDICATORS = [
    /\b\d+%\b/,                    // Percentages
    /\b\$[\d,]+\b/,                // Dollar amounts
    /\b\d+[kK]\b/,                 // Thousands (10k, 5K)
    /\b\d+[mM]\b/,                 // Millions (2m, 3M)
    /\b\d+\s*(million|thousand|billion)\b/i, // Written numbers
    /\b\d+\s*(users?|customers?|clients?)\b/i, // User counts
    /\b\d+\s*(hours?|days?|weeks?|months?|years?)\b/i, // Time periods
    /\b(increased|decreased|improved|reduced|grew|saved|generated)\b/i // Action indicators
  ];

  private static readonly STRONG_ACTION_VERBS = [
    'achieved', 'built', 'created', 'developed', 'designed', 'implemented',
    'led', 'managed', 'optimized', 'improved', 'increased', 'reduced',
    'delivered', 'launched', 'established', 'streamlined', 'automated',
    'collaborated', 'coordinated', 'facilitated', 'mentored', 'trained'
  ];

  /**
   * Parse resume file and extract structured content
   */
  async parseResume(file: Express.Multer.File): Promise<ParsedResume> {
    const startTime = Date.now();
    
    try {
      logger.info('Starting resume parsing', {
        filename: file.originalname,
        size: file.size,
        mimetype: file.mimetype
      });

      // Validate file exists
      if (!fs.existsSync(file.path)) {
        throw createError('Resume file not found', 404);
      }

      // Extract text based on file type
      let rawText: string;
      let extractionMethod: 'pdf-parse' | 'mammoth' | 'manual';

      if (file.mimetype === 'application/pdf') {
        rawText = await this.extractPdfText(file.path);
        extractionMethod = 'pdf-parse';
      } else if (file.mimetype === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
        rawText = await this.extractDocxText(file.path);
        extractionMethod = 'mammoth';
      } else if (file.mimetype === 'application/msword') {
        rawText = await this.extractDocText(file.path);
        extractionMethod = 'mammoth';
      } else {
        throw createError(`Unsupported file type: ${file.mimetype}`, 400);
      }

      // Calculate processing time
      const processingTime = Date.now() - startTime;

      // Parse sections from raw text
      const sections = this.parseSections(rawText);

      // Calculate extraction confidence
      const extractionConfidence = this.calculateExtractionConfidence(rawText, sections);

      // Create metadata
      const metadata: DocumentMetadata = {
        fileName: file.originalname,
        fileSize: file.size,
        pageCount: this.estimatePageCount(rawText),
        extractionMethod,
        processingTime,
        warnings: this.generateWarnings(rawText, sections)
      };

      const parsedResume: ParsedResume = {
        rawText,
        sections,
        metadata,
        extractionConfidence
      };

      logger.info('Resume parsing completed', {
        filename: file.originalname,
        processingTime,
        extractionConfidence,
        sectionsFound: sections.length,
        textLength: rawText.length
      });

      return parsedResume;

    } catch (error) {
      logger.error('Resume parsing failed', {
        filename: file.originalname,
        error: error instanceof Error ? error.message : 'Unknown error',
        processingTime: Date.now() - startTime
      });
      throw error;
    }
  }

  /**
   * Validate file before parsing
   */
  validateFile(file: Express.Multer.File): ValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    // File existence
    if (!file || !fs.existsSync(file.path)) {
      errors.push('File not found or inaccessible');
    }

    // File size
    if (file.size === 0) {
      errors.push('File is empty');
    } else if (file.size > 10 * 1024 * 1024) { // 10MB
      errors.push('File too large for processing');
    }

    // File type
    const supportedTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];

    if (!supportedTypes.includes(file.mimetype)) {
      errors.push(`Unsupported file type: ${file.mimetype}`);
    }

    // Warnings
    if (file.size > 5 * 1024 * 1024) { // 5MB
      warnings.push('Large file may take longer to process');
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings
    };
  }

  /**
   * Extract text from PDF file
   */
  private async extractPdfText(filePath: string): Promise<string> {
    try {
      const dataBuffer = fs.readFileSync(filePath);
      const data = await pdfParse(dataBuffer);
      
      if (!data.text || data.text.trim().length === 0) {
        throw createError('PDF appears to be empty or contains only images', 400);
      }

      return data.text;
    } catch (error) {
      logger.error('PDF extraction failed', { filePath, error });
      throw createError('Failed to extract text from PDF. The file may be corrupted or password-protected.', 400);
    }
  }

  /**
   * Extract text from DOCX file
   */
  private async extractDocxText(filePath: string): Promise<string> {
    try {
      const result = await mammoth.extractRawText({ path: filePath });
      
      if (!result.value || result.value.trim().length === 0) {
        throw createError('DOCX appears to be empty', 400);
      }

      // Log any conversion warnings
      if (result.messages.length > 0) {
        logger.warn('DOCX conversion warnings', {
          filePath,
          warnings: result.messages.map(m => m.message)
        });
      }

      return result.value;
    } catch (error) {
      logger.error('DOCX extraction failed', { filePath, error });
      throw createError('Failed to extract text from DOCX. The file may be corrupted.', 400);
    }
  }

  /**
   * Extract text from DOC file (legacy format)
   */
  private async extractDocText(filePath: string): Promise<string> {
    try {
      // Mammoth can handle some DOC files, but with limited support
      const result = await mammoth.extractRawText({ path: filePath });
      
      if (!result.value || result.value.trim().length === 0) {
        throw createError('DOC file appears to be empty or in an unsupported format', 400);
      }

      return result.value;
    } catch (error) {
      logger.error('DOC extraction failed', { filePath, error });
      throw createError('Failed to extract text from DOC. Please convert to DOCX or PDF format.', 400);
    }
  }

  /**
   * Parse sections from raw text
   */
  private parseSections(rawText: string): ResumeSection[] {
    const lines = rawText.split('\n').map(line => line.trim()).filter(line => line.length > 0);
    const sections: ResumeSection[] = [];
    let currentSection: ResumeSection | null = null;
    let lineNumber = 0;

    for (const line of lines) {
      lineNumber++;

      // Check if this line is a section header
      const sectionType = this.identifySectionType(line);
      
      if (sectionType) {
        // Save previous section if exists
        if (currentSection) {
          sections.push(currentSection);
        }

        // Start new section
        currentSection = {
          id: `section_${sections.length + 1}`,
          type: sectionType,
          title: line,
          content: '',
          bullets: [],
          startLine: lineNumber
        };
      } else if (currentSection) {
        // Add content to current section
        currentSection.content += line + '\n';

        // Check if this is a bullet point
        if (this.isBulletPoint(line)) {
          const bullet = this.parseBulletPoint(line, `${currentSection.id}_bullet_${currentSection.bullets.length + 1}`, lineNumber);
          currentSection.bullets.push(bullet);
        }
      } else {
        // No current section - this might be contact info or summary at the top
        if (!sections.length) {
          currentSection = {
            id: 'section_1',
            type: SectionType.CONTACT,
            title: 'Contact Information',
            content: line + '\n',
            bullets: [],
            startLine: lineNumber
          };
        }
      }
    }

    // Add final section
    if (currentSection) {
      currentSection.endLine = lineNumber;
      sections.push(currentSection);
    }

    return sections;
  }

  /**
   * Identify section type from header text
   */
  private identifySectionType(line: string): SectionType | null {
    const cleanLine = line.toLowerCase().trim();
    
    // Skip very short lines
    if (cleanLine.length < 3) {
      return null;
    }

    // Check against known patterns
    for (const [sectionType, pattern] of Object.entries(ResumeParser.SECTION_PATTERNS)) {
      if (pattern.test(cleanLine)) {
        return sectionType as SectionType;
      }
    }

    // Check if line looks like a section header (all caps, short, etc.)
    if (cleanLine === cleanLine.toUpperCase() && cleanLine.length < 30 && !cleanLine.includes('.')) {
      return SectionType.OTHER;
    }

    return null;
  }

  /**
   * Check if line is a bullet point
   */
  private isBulletPoint(line: string): boolean {
    return ResumeParser.BULLET_PATTERNS.some(pattern => pattern.test(line));
  }

  /**
   * Parse bullet point and extract achievements
   */
  private parseBulletPoint(line: string, id: string, lineNumber: number): BulletPoint {
    // Remove bullet marker
    let cleanText = line;
    for (const pattern of ResumeParser.BULLET_PATTERNS) {
      cleanText = cleanText.replace(pattern, '').trim();
    }

    // Extract achievements
    const achievements = this.extractAchievements(cleanText);

    return {
      id,
      text: cleanText,
      lineNumber,
      achievements
    };
  }

  /**
   * Extract achievements from text
   */
  private extractAchievements(text: string): Achievement[] {
    const achievements: Achievement[] = [];
    
    // Check for quantified achievements
    const metrics: string[] = [];
    let hasQuantification = false;

    for (const pattern of ResumeParser.ACHIEVEMENT_INDICATORS) {
      const matches = text.match(pattern);
      if (matches) {
        hasQuantification = true;
        metrics.push(...matches);
      }
    }

    // Check for strong action verbs
    const actionVerbs: string[] = [];
    const words = text.toLowerCase().split(/\s+/);
    
    for (const verb of ResumeParser.STRONG_ACTION_VERBS) {
      if (words.includes(verb)) {
        actionVerbs.push(verb);
      }
    }

    // Create achievement if we found indicators
    if (hasQuantification || actionVerbs.length > 0) {
      achievements.push({
        text,
        hasQuantification,
        metrics,
        actionVerbs
      });
    }

    return achievements;
  }

  /**
   * Calculate extraction confidence score
   */
  private calculateExtractionConfidence(rawText: string, sections: ResumeSection[]): number {
    let confidence = 100;

    // Penalize very short text
    if (rawText.length < 500) {
      confidence -= 30;
    } else if (rawText.length < 1000) {
      confidence -= 15;
    }

    // Penalize if no sections found
    if (sections.length === 0) {
      confidence -= 40;
    } else if (sections.length < 3) {
      confidence -= 20;
    }

    // Bonus for finding key sections
    const hasExperience = sections.some(s => s.type === SectionType.EXPERIENCE);
    const hasEducation = sections.some(s => s.type === SectionType.EDUCATION);
    const hasSkills = sections.some(s => s.type === SectionType.SKILLS);

    if (!hasExperience) confidence -= 15;
    if (!hasEducation) confidence -= 10;
    if (!hasSkills) confidence -= 10;

    // Penalize for too much garbled text
    const garbledRatio = this.calculateGarbledTextRatio(rawText);
    if (garbledRatio > 0.1) {
      confidence -= Math.floor(garbledRatio * 100);
    }

    return Math.max(0, Math.min(100, confidence));
  }

  /**
   * Calculate ratio of garbled/unreadable text
   */
  private calculateGarbledTextRatio(text: string): number {
    const totalChars = text.length;
    if (totalChars === 0) return 1;

    // Count non-printable or unusual characters
    const garbledChars = (text.match(/[^\w\s\-.,!?@#$%^&*()+={}[\]|\\:";'<>?/~`]/g) || []).length;
    
    return garbledChars / totalChars;
  }

  /**
   * Estimate page count from text length
   */
  private estimatePageCount(text: string): number {
    // Rough estimate: 500 words per page, average 5 characters per word
    const estimatedWords = text.length / 5;
    return Math.max(1, Math.ceil(estimatedWords / 500));
  }

  /**
   * Generate warnings based on parsing results
   */
  private generateWarnings(rawText: string, sections: ResumeSection[]): string[] {
    const warnings: string[] = [];

    // Text quality warnings
    if (rawText.length < 500) {
      warnings.push('Resume appears very short - may be missing content');
    }

    if (this.calculateGarbledTextRatio(rawText) > 0.05) {
      warnings.push('Some text may not have been extracted correctly');
    }

    // Section warnings
    if (sections.length < 3) {
      warnings.push('Few sections detected - formatting may affect analysis accuracy');
    }

    const hasExperience = sections.some(s => s.type === SectionType.EXPERIENCE);
    if (!hasExperience) {
      warnings.push('No work experience section detected');
    }

    // Bullet point warnings
    const totalBullets = sections.reduce((sum, section) => sum + section.bullets.length, 0);
    if (totalBullets < 5) {
      warnings.push('Few bullet points detected - may affect achievement analysis');
    }

    return warnings;
  }
}