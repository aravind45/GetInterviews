// Component exports and factory functions

import { ResumeParser } from './ResumeParser';

// Factory function for ResumeParser
export const createResumeParser = (): ResumeParser => {
  return new ResumeParser();
};

// Re-export components
export { ResumeParser };

// Component interfaces
export interface ComponentFactory {
  createResumeParser(): ResumeParser;
}

export const componentFactory: ComponentFactory = {
  createResumeParser
};