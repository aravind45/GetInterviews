import Groq from 'groq-sdk';
import { logger } from '../utils/logger';

let groqClient: Groq;

export const initializeGroq = (): void => {
  if (!process.env.GROQ_API_KEY) {
    throw new Error('GROQ_API_KEY environment variable is required');
  }

  groqClient = new Groq({
    apiKey: process.env.GROQ_API_KEY,
  });

  logger.info('Groq client initialized');
};

export const getGroqClient = (): Groq => {
  if (!groqClient) {
    initializeGroq();
  }
  return groqClient;
};

export interface GroqAnalysisRequest {
  resumeText: string;
  targetJobTitle: string;
  jobDescription?: string;
  analysisType: 'experience_level' | 'achievement_quality' | 'industry_transition';
}

export interface GroqAnalysisResponse {
  analysis: string;
  confidence: number;
  evidence: string[];
  recommendations: string[];
}

export const analyzeWithGroq = async (
  request: GroqAnalysisRequest
): Promise<GroqAnalysisResponse> => {
  try {
    const client = getGroqClient();
    
    const systemPrompt = getSystemPrompt(request.analysisType);
    const userPrompt = buildUserPrompt(request);

    const completion = await client.chat.completions.create({
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      model: process.env.GROQ_MODEL || 'llama3-8b-8192',
      temperature: 0.1, // Low temperature for consistent analysis
      max_tokens: 1000,
      top_p: 0.9,
    });

    const response = completion.choices[0]?.message?.content;
    if (!response) {
      throw new Error('No response from Groq API');
    }

    // Parse structured response
    return parseGroqResponse(response);
  } catch (error) {
    logger.error('Groq analysis error:', error);
    throw new Error(`AI analysis failed: ${error}`);
  }
};

const getSystemPrompt = (analysisType: string): string => {
  const basePrompt = `You are an expert resume analyst. Analyze the provided resume against the target job requirements. 

CRITICAL RULES:
- Only cite evidence that exists in the provided resume text
- Do not invent or hallucinate skills, experience, or achievements
- Provide specific text references for all claims
- Return analysis in JSON format with: analysis, confidence (0-100), evidence (array), recommendations (array)`;

  switch (analysisType) {
    case 'experience_level':
      return `${basePrompt}

Focus on: Experience level alignment with target role requirements. Assess if the candidate's years of experience, seniority level, and responsibility scope match the target position.`;

    case 'achievement_quality':
      return `${basePrompt}

Focus on: Quality of achievement descriptions. Look for quantified results, impact metrics, specific outcomes, and strong action verbs. Identify weak or generic descriptions.`;

    case 'industry_transition':
      return `${basePrompt}

Focus on: Industry transition challenges. Assess how well the candidate explains their move between industries and demonstrates transferable skills.`;

    default:
      return basePrompt;
  }
};

const buildUserPrompt = (request: GroqAnalysisRequest): string => {
  let prompt = `Resume Text:\n${request.resumeText}\n\nTarget Job Title: ${request.targetJobTitle}`;
  
  if (request.jobDescription) {
    prompt += `\n\nJob Description:\n${request.jobDescription}`;
  }
  
  prompt += '\n\nProvide your analysis in JSON format.';
  
  return prompt;
};

const parseGroqResponse = (response: string): GroqAnalysisResponse => {
  try {
    // Try to extract JSON from response
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('No JSON found in response');
    }
    
    const parsed = JSON.parse(jsonMatch[0]);
    
    return {
      analysis: parsed.analysis || '',
      confidence: Math.min(100, Math.max(0, parsed.confidence || 0)),
      evidence: Array.isArray(parsed.evidence) ? parsed.evidence : [],
      recommendations: Array.isArray(parsed.recommendations) ? parsed.recommendations : []
    };
  } catch (error) {
    logger.error('Failed to parse Groq response:', error);
    
    // Fallback: return basic analysis
    return {
      analysis: response.substring(0, 500),
      confidence: 50,
      evidence: [],
      recommendations: []
    };
  }
};