import multer from 'multer';
import crypto from 'crypto';
import path from 'path';
import fs from 'fs';
import { Request } from 'express';
import { createError } from './errorHandler';
import { logger } from '../utils/logger';

// Supported file types
const SUPPORTED_MIME_TYPES = [
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
];

const SUPPORTED_EXTENSIONS = ['.pdf', '.doc', '.docx'];

// File size limits (10MB default, configurable via env)
const MAX_FILE_SIZE = parseInt(process.env.MAX_FILE_SIZE || '10485760'); // 10MB

// Create upload directory if it doesn't exist
const uploadDir = process.env.UPLOAD_DIR || './uploads';
const tempDir = process.env.TEMP_DIR || './temp';

[uploadDir, tempDir].forEach(dir => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

// Custom storage configuration for encrypted temporary storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, tempDir);
  },
  filename: (req, file, cb) => {
    // Generate secure random filename
    const randomName = crypto.randomBytes(16).toString('hex');
    const extension = path.extname(file.originalname).toLowerCase();
    cb(null, `${randomName}${extension}`);
  }
});

// File filter for validation
const fileFilter = (req: Request, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
  try {
    // Check MIME type
    if (!SUPPORTED_MIME_TYPES.includes(file.mimetype)) {
      logger.warn(`Unsupported file type attempted: ${file.mimetype}`, {
        originalName: file.originalname,
        ip: req.ip
      });
      return cb(createError(`Unsupported file type. Please upload PDF, DOC, or DOCX files only.`, 400));
    }

    // Check file extension
    const extension = path.extname(file.originalname).toLowerCase();
    if (!SUPPORTED_EXTENSIONS.includes(extension)) {
      logger.warn(`Unsupported file extension attempted: ${extension}`, {
        originalName: file.originalname,
        ip: req.ip
      });
      return cb(createError(`Unsupported file extension. Please upload .pdf, .doc, or .docx files only.`, 400));
    }

    // Additional security check: ensure filename doesn't contain dangerous characters
    const filename = file.originalname;
    if (filename.includes('..') || filename.includes('/') || filename.includes('\\')) {
      logger.warn(`Potentially dangerous filename attempted: ${filename}`, {
        ip: req.ip
      });
      return cb(createError(`Invalid filename. Please use a standard filename without special characters.`, 400));
    }

    cb(null, true);
  } catch (error) {
    logger.error('File filter error:', error);
    cb(createError('File validation failed', 500));
  }
};

// Configure multer
export const uploadMiddleware = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: MAX_FILE_SIZE,
    files: 1, // Only allow one file per request
    fields: 10, // Limit form fields
    fieldNameSize: 100, // Limit field name size
    fieldSize: 1024 * 1024 // 1MB limit for form field values
  }
});

// File validation interface
export interface FileValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  fileInfo?: {
    originalName: string;
    size: number;
    mimetype: string;
    extension: string;
    tempPath: string;
  };
}

// Enhanced file validation function
export const validateUploadedFile = (file: Express.Multer.File): FileValidationResult => {
  const errors: string[] = [];
  const warnings: string[] = [];

  try {
    // Basic file existence check
    if (!file) {
      errors.push('No file provided');
      return { isValid: false, errors, warnings };
    }

    // File size validation
    if (file.size === 0) {
      errors.push('File is empty');
    } else if (file.size > MAX_FILE_SIZE) {
      errors.push(`File size (${Math.round(file.size / 1024 / 1024)}MB) exceeds maximum allowed size (${Math.round(MAX_FILE_SIZE / 1024 / 1024)}MB)`);
    }

    // File extension validation
    const extension = path.extname(file.originalname).toLowerCase();
    if (!SUPPORTED_EXTENSIONS.includes(extension)) {
      errors.push(`Unsupported file extension: ${extension}`);
    }

    // MIME type validation
    if (!SUPPORTED_MIME_TYPES.includes(file.mimetype)) {
      errors.push(`Unsupported MIME type: ${file.mimetype}`);
    }

    // File path validation
    if (!fs.existsSync(file.path)) {
      errors.push('Uploaded file not found on disk');
    }

    // Warnings for potentially problematic files
    if (file.size > 5 * 1024 * 1024) { // 5MB
      warnings.push('Large file size may result in slower processing');
    }

    if (file.originalname.length > 100) {
      warnings.push('Very long filename may be truncated in results');
    }

    const fileInfo = {
      originalName: file.originalname,
      size: file.size,
      mimetype: file.mimetype,
      extension,
      tempPath: file.path
    };

    return {
      isValid: errors.length === 0,
      errors,
      warnings,
      fileInfo
    };
  } catch (error) {
    logger.error('File validation error:', error);
    return {
      isValid: false,
      errors: ['File validation failed due to internal error'],
      warnings
    };
  }
};

// Secure file cleanup function
export const cleanupTempFile = async (filePath: string): Promise<void> => {
  try {
    if (fs.existsSync(filePath)) {
      // Secure deletion: overwrite file before deletion
      const stats = fs.statSync(filePath);
      const fd = fs.openSync(filePath, 'r+');
      
      // Overwrite with random data
      const buffer = crypto.randomBytes(Math.min(stats.size, 1024 * 1024)); // Max 1MB overwrite
      fs.writeSync(fd, buffer, 0, buffer.length, 0);
      fs.fsyncSync(fd);
      fs.closeSync(fd);
      
      // Delete the file
      fs.unlinkSync(filePath);
      
      logger.debug(`Securely deleted temp file: ${filePath}`);
    }
  } catch (error) {
    logger.error(`Failed to cleanup temp file ${filePath}:`, error);
    // Don't throw - cleanup failures shouldn't break the main flow
  }
};

// File encryption utilities for temporary storage
export const encryptFileContent = (content: Buffer, key: string): Buffer => {
  try {
    const algorithm = 'aes-256-gcm';
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipher(algorithm, key);
    
    const encrypted = Buffer.concat([cipher.update(content), cipher.final()]);
    const authTag = cipher.getAuthTag();
    
    // Combine IV, auth tag, and encrypted content
    return Buffer.concat([iv, authTag, encrypted]);
  } catch (error) {
    logger.error('File encryption error:', error);
    throw createError('File encryption failed', 500);
  }
};

export const decryptFileContent = (encryptedContent: Buffer, key: string): Buffer => {
  try {
    const algorithm = 'aes-256-gcm';
    const iv = encryptedContent.slice(0, 16);
    const authTag = encryptedContent.slice(16, 32);
    const encrypted = encryptedContent.slice(32);
    
    const decipher = crypto.createDecipher(algorithm, key);
    decipher.setAuthTag(authTag);
    
    const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);
    return decrypted;
  } catch (error) {
    logger.error('File decryption error:', error);
    throw createError('File decryption failed', 500);
  }
};