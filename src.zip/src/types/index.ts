// Core domain types for Resume Diagnosis Engine

export interface ParsedResume {
  rawText: string;
  sections: ResumeSection[];
  metadata: DocumentMetadata;
  extractionConfidence: number;
}

export interface ResumeSection {
  id: string;
  type: SectionType;
  title: string;
  content: string;
  bullets: BulletPoint[];
  startLine?: number;
  endLine?: number;
}

export interface BulletPoint {
  id: string;
  text: string;
  lineNumber?: number;
  achievements: Achievement[];
}

export interface Achievement {
  text: string;
  hasQuantification: boolean;
  metrics: string[];
  actionVerbs: string[];
}

export interface DocumentMetadata {
  fileName: string;
  fileSize: number;
  pageCount: number;
  extractionMethod: 'pdf-parse' | 'mammoth' | 'manual';
  processingTime: number;
  warnings: string[];
}

export enum SectionType {
  CONTACT = 'contact',
  SUMMARY = 'summary',
  EXPERIENCE = 'experience',
  EDUCATION = 'education',
  SKILLS = 'skills',
  PROJECTS = 'projects',
  CERTIFICATIONS = 'certifications',
  OTHER = 'other'
}

export interface NormalizedTitle {
  canonical: string;
  confidence: number;
  alternatives: string[];
  requiresSpecialization: boolean;
  category: string;
  seniorityLevel: string;
}

export interface DiagnosisResult {
  rootCauses: RootCause[];
  evidence: Evidence[];
  recommendations: Recommendation[];
  overallFitScore: number;
  confidenceScore: number;
  processingMetadata: ProcessingMetadata;
}

export interface RootCause {
  id: string;
  title: string;
  description: string;
  severity: number;        // 1-10
  impact: number;         // 1-10
  category: ProblemCategory;
  evidence: Evidence[];
  recommendations: Recommendation[];
}

export interface Evidence {
  type: EvidenceType;
  description: string;
  location: EvidenceLocation;
  example: string;
  confidence: number;     // 0-100
}

export interface EvidenceLocation {
  sectionId: string;
  bulletId?: string;
  charSpan?: { start: number; end: number };
  pageNumber?: number;
  lineNumber?: number;
}

export interface Recommendation {
  priority: number;       // 1-3 (top 3 only)
  action: string;
  rationale: string;
  expectedImpact: string;
  difficulty: DifficultyLevel;
  category: ProblemCategory;
}

export interface ProcessingMetadata {
  analysisStartTime: Date;
  analysisEndTime: Date;
  totalProcessingTime: number;
  groqModelUsed?: string;
  deterministicAnalysisCount: number;
  modelAssistedAnalysisCount: number;
  cacheHits: number;
}

export enum ProblemCategory {
  KEYWORD_GAPS = 'keyword_gaps',
  SKILLS_MISMATCH = 'skills_mismatch',
  EXPERIENCE_LEVEL = 'experience_level',
  ATS_COMPATIBILITY = 'ats_compatibility',
  ACHIEVEMENT_QUALITY = 'achievement_quality',
  INDUSTRY_TRANSITION = 'industry_transition'
}

export enum EvidenceType {
  MISSING_KEYWORD = 'missing_keyword',
  WEAK_DESCRIPTION = 'weak_description',
  FORMAT_ISSUE = 'format_issue',
  SKILL_GAP = 'skill_gap',
  LEVEL_MISMATCH = 'level_mismatch'
}

export enum DifficultyLevel {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high'
}

export enum AnalysisType {
  DETERMINISTIC = 'deterministic',
  MODEL_ASSISTED = 'model_assisted'
}

// Database entity types
export interface CanonicalJobTitle {
  id: string;
  title: string;
  category: string;
  seniorityLevel: string;
  industry?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface JobTitleVariation {
  id: string;
  canonicalId: string;
  variation: string;
  confidenceScore: number;
  createdAt: Date;
}

export interface RoleTemplate {
  id: string;
  canonicalJobId: string;
  requiredSkills: string[];
  preferredSkills: string[];
  requiredKeywords: string[];
  experienceLevelMin: number;
  experienceLevelMax?: number;
  educationRequirements: string[];
  industryContext: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export interface UserSession {
  id: string;
  sessionToken: string;
  ipAddress?: string;
  userAgent?: string;
  createdAt: Date;
  expiresAt: Date;
  isActive: boolean;
}

export interface ResumeAnalysis {
  id: string;
  sessionId: string;
  fileHash: string;
  encryptedContent: Buffer;
  targetJobTitle: string;
  canonicalJobId?: string;
  analysisStatus: 'pending' | 'processing' | 'completed' | 'failed';
  confidenceScore?: number;
  createdAt: Date;
  expiresAt: Date;
  deletedAt?: Date;
}

// API request/response types
export interface AnalyzeResumeRequest {
  targetJobTitle: string;
  jobDescriptions?: string[];
  applicationCount?: number;
}

export interface AnalyzeResumeResponse {
  success: boolean;
  data?: DiagnosisResult;
  error?: string;
  sessionId: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

export interface SpecificityResult {
  isSpecific: boolean;
  suggestions: string[];
  confidence: number;
}