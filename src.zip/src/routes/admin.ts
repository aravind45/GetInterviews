import { Router, Request, Response, NextFunction } from 'express';
import { runMigrations } from '../database/migrate';
import { seedDatabase } from '../database/seed';
import { createError } from '../middleware/errorHandler';
import { logger } from '../utils/logger';

const router = Router();

// Simple admin authentication (in production, use proper auth)
const adminAuth = (req: Request, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  const adminKey = process.env.ADMIN_KEY;
  
  if (!adminKey) {
    return next(createError('Admin operations not configured', 503));
  }
  
  if (!authHeader || authHeader !== `Bearer ${adminKey}`) {
    return next(createError('Unauthorized', 401));
  }
  
  next();
};

/**
 * POST /api/admin/migrate
 * Run database migrations
 */
router.post('/migrate', adminAuth, async (req: Request, res: Response, next: NextFunction) => {
  try {
    logger.info('Starting database migration via API');
    
    await runMigrations();
    
    logger.info('Database migration completed successfully');
    
    res.json({
      success: true,
      message: 'Database migrations completed successfully',
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    logger.error('Database migration failed via API:', error);
    next(createError('Database migration failed', 500));
  }
});

/**
 * POST /api/admin/seed
 * Seed database with initial data
 */
router.post('/seed', adminAuth, async (req: Request, res: Response, next: NextFunction) => {
  try {
    logger.info('Starting database seeding via API');
    
    await seedDatabase();
    
    logger.info('Database seeding completed successfully');
    
    res.json({
      success: true,
      message: 'Database seeded successfully',
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    logger.error('Database seeding failed via API:', error);
    next(createError('Database seeding failed', 500));
  }
});

/**
 * GET /api/admin/health
 * Comprehensive health check
 */
router.get('/health', adminAuth, async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { query } = require('../database/connection');
    const { getRedisClient } = require('../cache/redis');
    
    // Test database connection
    const dbResult = await query('SELECT NOW() as db_time, version() as db_version');
    const dbHealth = {
      connected: true,
      time: dbResult.rows[0].db_time,
      version: dbResult.rows[0].db_version
    };
    
    // Test Redis connection
    let redisHealth;
    try {
      const redisClient = getRedisClient();
      await redisClient.ping();
      redisHealth = { connected: true };
    } catch (error) {
      redisHealth = { connected: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
    
    // Test Groq API (basic check)
    let groqHealth;
    try {
      const { getGroqClient } = require('../services/groq');
      const groqClient = getGroqClient();
      groqHealth = { configured: !!groqClient };
    } catch (error) {
      groqHealth = { configured: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
    
    res.json({
      success: true,
      timestamp: new Date().toISOString(),
      environment: process.env.NODE_ENV,
      services: {
        database: dbHealth,
        redis: redisHealth,
        groq: groqHealth
      },
      system: {
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        version: process.version
      }
    });
    
  } catch (error) {
    logger.error('Health check failed:', error);
    next(createError('Health check failed', 500));
  }
});

/**
 * POST /api/admin/cleanup
 * Manual cleanup of expired data
 */
router.post('/cleanup', adminAuth, async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { query } = require('../database/connection');
    
    // Run cleanup function
    const result = await query('SELECT cleanup_expired_data() as deleted_count');
    const deletedCount = result.rows[0].deleted_count;
    
    logger.info(`Manual cleanup completed, deleted ${deletedCount} expired records`);
    
    res.json({
      success: true,
      message: `Cleanup completed successfully`,
      deletedRecords: deletedCount,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    logger.error('Manual cleanup failed:', error);
    next(createError('Cleanup operation failed', 500));
  }
});

export default router;