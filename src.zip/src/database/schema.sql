-- Resume Diagnosis Engine Database Schema

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Job titles and normalization tables
CREATE TABLE canonical_job_titles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(255) NOT NULL UNIQUE,
    category VARCHAR(100) NOT NULL,
    seniority_level VARCHAR(50) NOT NULL,
    industry VARCHAR(100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE job_title_variations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    canonical_id UUID NOT NULL REFERENCES canonical_job_titles(id) ON DELETE CASCADE,
    variation VARCHAR(255) NOT NULL,
    confidence_score INTEGER NOT NULL CHECK (confidence_score >= 0 AND confidence_score <= 100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_job_title_variations_variation ON job_title_variations(variation);
CREATE INDEX idx_job_title_variations_canonical ON job_title_variations(canonical_id);

-- Role templates for analysis
CREATE TABLE role_templates (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    canonical_job_id UUID NOT NULL REFERENCES canonical_job_titles(id) ON DELETE CASCADE,
    required_skills TEXT[] NOT NULL,
    preferred_skills TEXT[],
    required_keywords TEXT[] NOT NULL,
    experience_level_min INTEGER NOT NULL CHECK (experience_level_min >= 0),
    experience_level_max INTEGER CHECK (experience_level_max >= experience_level_min),
    education_requirements TEXT[],
    industry_context JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_role_templates_canonical ON role_templates(canonical_job_id);

-- User sessions and analysis tracking
CREATE TABLE user_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_token VARCHAR(255) NOT NULL UNIQUE,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE
);

CREATE INDEX idx_user_sessions_token ON user_sessions(session_token);
CREATE INDEX idx_user_sessions_expires ON user_sessions(expires_at);

-- Resume analysis records (encrypted and temporary)
CREATE TABLE resume_analyses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id UUID NOT NULL REFERENCES user_sessions(id) ON DELETE CASCADE,
    file_hash VARCHAR(64) NOT NULL, -- SHA-256 hash for deduplication
    encrypted_content BYTEA NOT NULL, -- Encrypted resume content
    target_job_title VARCHAR(255) NOT NULL,
    canonical_job_id UUID REFERENCES canonical_job_titles(id),
    analysis_status VARCHAR(50) NOT NULL DEFAULT 'pending',
    confidence_score INTEGER CHECK (confidence_score >= 0 AND confidence_score <= 100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL, -- 24-hour TTL
    deleted_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_resume_analyses_session ON resume_analyses(session_id);
CREATE INDEX idx_resume_analyses_expires ON resume_analyses(expires_at);
CREATE INDEX idx_resume_analyses_hash ON resume_analyses(file_hash);

-- Analysis results (structured findings)
CREATE TABLE analysis_results (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    analysis_id UUID NOT NULL REFERENCES resume_analyses(id) ON DELETE CASCADE,
    root_causes JSONB NOT NULL, -- Array of root cause objects
    recommendations JSONB NOT NULL, -- Array of recommendation objects
    evidence JSONB NOT NULL, -- Array of evidence objects
    scores JSONB NOT NULL, -- Severity, impact, confidence scores
    processing_metadata JSONB, -- Analysis timing, model versions, etc.
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_analysis_results_analysis ON analysis_results(analysis_id);

-- Audit log for data operations
CREATE TABLE audit_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    table_name VARCHAR(100) NOT NULL,
    operation VARCHAR(20) NOT NULL, -- INSERT, UPDATE, DELETE
    record_id UUID NOT NULL,
    session_id UUID REFERENCES user_sessions(id),
    old_values JSONB,
    new_values JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_audit_log_table_operation ON audit_log(table_name, operation);
CREATE INDEX idx_audit_log_created ON audit_log(created_at);

-- Data cleanup functions and triggers
CREATE OR REPLACE FUNCTION cleanup_expired_data()
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER := 0;
BEGIN
    -- Mark expired analyses as deleted
    UPDATE resume_analyses 
    SET deleted_at = NOW()
    WHERE expires_at < NOW() AND deleted_at IS NULL;
    
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    
    -- Delete expired sessions
    DELETE FROM user_sessions 
    WHERE expires_at < NOW();
    
    -- Clean up old audit logs (keep for 7 days)
    DELETE FROM audit_log 
    WHERE created_at < NOW() - INTERVAL '7 days';
    
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- Audit trigger function
CREATE OR REPLACE FUNCTION audit_trigger_function()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        INSERT INTO audit_log (table_name, operation, record_id, old_values)
        VALUES (TG_TABLE_NAME, TG_OP, OLD.id, row_to_json(OLD));
        RETURN OLD;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO audit_log (table_name, operation, record_id, old_values, new_values)
        VALUES (TG_TABLE_NAME, TG_OP, NEW.id, row_to_json(OLD), row_to_json(NEW));
        RETURN NEW;
    ELSIF TG_OP = 'INSERT' THEN
        INSERT INTO audit_log (table_name, operation, record_id, new_values)
        VALUES (TG_TABLE_NAME, TG_OP, NEW.id, row_to_json(NEW));
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create audit triggers for sensitive tables
CREATE TRIGGER audit_resume_analyses
    AFTER INSERT OR UPDATE OR DELETE ON resume_analyses
    FOR EACH ROW EXECUTE FUNCTION audit_trigger_function();

CREATE TRIGGER audit_user_sessions
    AFTER INSERT OR UPDATE OR DELETE ON user_sessions
    FOR EACH ROW EXECUTE FUNCTION audit_trigger_function();

-- Updated timestamp triggers
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_canonical_job_titles_updated_at
    BEFORE UPDATE ON canonical_job_titles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_role_templates_updated_at
    BEFORE UPDATE ON role_templates
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();