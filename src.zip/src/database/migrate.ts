import fs from 'fs';
import path from 'path';
import { query } from './connection';
import { logger } from '../utils/logger';

export const runMigrations = async (): Promise<void> => {
  try {
    logger.info('Starting database migrations...');
    
    // Read and execute schema.sql
    const schemaPath = path.join(__dirname, 'schema.sql');
    const schemaSql = fs.readFileSync(schemaPath, 'utf8');
    
    // Split by semicolon and execute each statement
    const statements = schemaSql
      .split(';')
      .map(stmt => stmt.trim())
      .filter(stmt => stmt.length > 0);
    
    for (const statement of statements) {
      try {
        await query(statement);
        logger.debug(`Executed: ${statement.substring(0, 50)}...`);
      } catch (error) {
        // Log but continue for statements that might already exist
        logger.warn(`Migration statement failed (may be expected): ${error}`);
      }
    }
    
    logger.info('Database migrations completed successfully');
  } catch (error) {
    logger.error('Migration failed:', error);
    throw error;
  }
};

// Run migrations if this file is executed directly
if (require.main === module) {
  const { connectDatabase } = require('./connection');
  
  connectDatabase()
    .then(() => runMigrations())
    .then(() => {
      logger.info('Migrations completed');
      process.exit(0);
    })
    .catch((error: any) => {
      logger.error('Migration failed:', error);
      process.exit(1);
    });
}